import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as s3notification from 'aws-cdk-lib/aws-s3-notifications';
import * as path from 'path';

export class JohnLambdaStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // create lambda function
    const johnLambdaFunc = new lambda.Function(this, 'JohnZFunc1', {
      functionName: 'JohnZLambdaFunction1',
      runtime: lambda.Runtime.PYTHON_3_10, // python 3.10 as runtime
      handler: 'lambda_function.lambda_handler',
//      role: iam.Role.fromRoleArn(this, 'JohnLambdaRole', 'arn:aws:iam::992382386705:role/service-role/john-function_code001-role-7lhhpoy0'),
      code: lambda.Code.fromAsset(path.join(__dirname,'../johncodes/pycodes')) // location dir of python code
    });
    // create S3 bucket
    const johnS3Bucket = new s3.Bucket(this, 'JohnZS3Bucket1', {
      bucketName: 'johnzlambdas3bucketbycdk001', // bucket name
      removalPolicy: cdk.RemovalPolicy.DESTROY  // remove bucket on cdk destroy
    });
    // add event notification to S3 for lambda function
    johnS3Bucket.addEventNotification(s3.EventType.OBJECT_CREATED,new s3notification.LambdaDestination(johnLambdaFunc))
    // S3 notificatino can be sqs, sns and lambda
    // S3 bucket to call Lambda function
    // the other option is to add trigger from Lambda function to call S3 bucket
  }
}
