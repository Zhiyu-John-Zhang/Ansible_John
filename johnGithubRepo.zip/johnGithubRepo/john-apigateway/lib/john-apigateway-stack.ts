import * as cdk from 'aws-cdk-lib';
import { ApiGateway } from 'aws-cdk-lib/aws-events-targets';
import { Construct } from 'constructs';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';

export class JohnApigatewayStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // create rest api
    const johnRESTAPI = new apigateway.RestApi(this, 'JohnZRESTAPIRef', {
      restApiName: 'JohnZWebRestAPI',
      description: 'this is for testing mock integration',
      endpointTypes: [apigateway.EndpointType.REGIONAL]
    });
    // create API under root path / resources
    const johnRESTAPIResource = johnRESTAPI.root.addResource('JohnTest');
    // method type mock integrator
    const johnRESTAPIMethod = johnRESTAPIResource.addMethod('GET', new apigateway.MockIntegration({
        integrationResponses: [
          { statusCode: '200' },
        ],
        passthroughBehavior: apigateway.PassthroughBehavior.NEVER,
        requestTemplates: {
          'application/json': '{"Return input body": "$input.body"}'
        }
      })
    )
  }
}
