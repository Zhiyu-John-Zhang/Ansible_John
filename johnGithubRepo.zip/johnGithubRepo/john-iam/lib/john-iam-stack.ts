import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as iam from 'aws-cdk-lib/aws-iam';

export class JohnIamStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // The code for creating IAM group
    const johnGroup = new iam.Group(this, 'johngrpref',{
      groupName: 'john-group-cdk' // group name that will be created
    });
    // attach ec2full access policy
//    group.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEC2FullAccess'));
    // add existing server to group
//    group.addUser(iam.User.fromUserName(this, 'existingUser', 'surbhi'));
    // you can try to use ARN since in multi AWS account
    // use policy ARN s3 full access
    const johnS3Arn = 'arn:aws:iam::aws:policy/AmazonS3FullAccess';
    johnGroup.addManagedPolicy(iam.ManagedPolicy.fromManagedPolicyArn(this, 'AmazonS3FullAccess', johnS3Arn));
    // add existing user to the group
    const johnUser = iam.User.fromUserName(this, 'existingUser', 'surbhi');
    johnGroup.addUser(johnUser);
    // create a role
    const johnRole = new iam.Role(this, 'johnRoleRef', {
      roleName: 'johnCDKRole',
      assumedBy: new iam.ServicePrincipal("ec2.amazonaws.com"),
      managedPolicies: [iam.ManagedPolicy.fromManagedPolicyArn(this, 'johnEc2FullAccessPolicy', 'arn:aws:iam::aws:policy/AmazonEC2FullAccess')],
    });
    // create an inline policy and assign it to a role
    const johnPolicy = new iam.Policy(this, 'john-s3-read-policy', {
      policyName: 'johnS3Read',
      groups: [johnGroup],
      statements: [new iam.PolicyStatement({
        actions: [
				  "s3:ListAccessGrants",
				  "s3:ListAllMyBuckets",
				  "s3:ListBucket"],
        resources: ['arn:aws:s3:::cdk-hnb659fds-assets-992382386705-us-east-1']
      })],
      roles: [johnRole]
    });
    // create a new user
    const johnNewAccount = new iam.User(this, 'newUser', {
      userName: 'JohnBMO',
      password: cdk.SecretValue.unsafePlainText('BmoAWSpt@098123$'),
      passwordResetRequired: false,
      groups: [johnGroup]
    });
    // create an inline policy "sts:AssumeRole" for building user - role trust relationship and assign it to a role
    const userRolePolicy = new iam.Policy(this, 'userRoleTrustRelationPolicy', {
      policyName: 'johnAllowAssumeRolePolicy',
      statements: [new iam.PolicyStatement({
        actions: ['sts:AssumeRole'],
        resources: [johnRole.roleArn]
      })]
    });
    // build the trust relation between the new user and the new inline policy
    johnNewAccount.attachInlinePolicy(userRolePolicy);
  }
}