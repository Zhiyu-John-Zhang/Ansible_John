import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as s3notification from 'aws-cdk-lib/aws-s3-notifications';
import * as path from 'path';
import { ApiGateway } from 'aws-cdk-lib/aws-events-targets';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';

export class JohnLambdaApigatewayS3Stack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // create lambda function
    const johnZLambdaFunc = new lambda.Function(this, 'JohnZFunc2Ref', {
      functionName: 'JohnZLambdaFunction2',
      runtime: lambda.Runtime.PYTHON_3_10, // python 3.10 as runtime
      handler: 'lambda_function.lambda_handler',
//      role: iam.Role.fromRoleArn(this, 'JohnLambdaRole', 'arn:aws:iam::992382386705:role/service-role/john-function_code001-role-7lhhpoy0'),  // add existing role
      code: lambda.Code.fromAsset(path.join(__dirname,'../johncodes/listbkt')) // location dir of python code
    });
    // default role is created with cloudwathch log_group permission
    // add s3 full access to the created role
    johnZLambdaFunc.addToRolePolicy(new iam.PolicyStatement({
      actions: ['s3:*'],
      resources: ['*']
    }));

    // create rest api
    const johnZRESTAPI = new apigateway.RestApi(this, 'JohnZRESTAPI2Ref', {
      restApiName: 'JohnZWebRestAPI2',
      description: 'this is for testing API gateway as Lambda trigger',
      endpointTypes: [apigateway.EndpointType.REGIONAL],
      deployOptions: {
        stageName: 'john-dev'
      }
    });
    // create API resource under root path / resources
    const johnZRESTAPIResource = johnZRESTAPI.root.addResource('JohnTest');
    // create method for above resource - type mock integrator
    const johnRESTAPIMethod = johnZRESTAPIResource.addMethod('GET', new apigateway.LambdaIntegration(johnZLambdaFunc), {
      methodResponses: [
        { statusCode: '200' }
      ]
    })

    // create S3 bucket
/*    const johnZS3Bucket = new s3.Bucket(this, 'JohnZS3Bucket2Ref', {
      bucketName: 'johnzlambdas3bucketbycdk002', // bucket name
      removalPolicy: cdk.RemovalPolicy.DESTROY  // remove bucket on cdk destroy
    });
    // add event notification to S3 for lambda function
    johnZS3Bucket.addEventNotification(s3.EventType.OBJECT_CREATED,new s3notification.LambdaDestination(johnZLambdaFunc))
    // S3 notificatino can be sqs, sns and lambda
    // S3 bucket to call Lambda function
    // the other option is to add trigger from Lambda function to call S3 bucket
*/
  }
}
