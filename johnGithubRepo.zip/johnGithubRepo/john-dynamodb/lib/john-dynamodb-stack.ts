import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as path from 'path';
export class JohnDynamodbStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

   // create dynamodb table
   const johnZDynamoDB = new dynamodb.Table(this, 'JohnZDynamoDBRef', {
    tableName: 'JohnZDynamoDBTable1',
    partitionKey: { name: 'id', type: dynamodb.AttributeType.NUMBER },
    removalPolicy: cdk.RemovalPolicy.DESTROY,
  });

  // lambda function to insert data
  const JohnLambdaFunction = new lambda.Function(this, 'JohnLambdaRef', {
    functionName: 'JohnLambda4DynamoDB',
    runtime: lambda.Runtime.PYTHON_3_10,
    handler: 'lambda_function.handler',
    code: lambda.Code.fromAsset(path.join(__dirname, '../johncodes/dbscripts')),
    environment: {
      TABLE_NAME: johnZDynamoDB.tableName
    }
  });

  // permission to lambda to write in dynamodb table
  johnZDynamoDB.grantWriteData(JohnLambdaFunction);

  // optional - use IAM policy
  JohnLambdaFunction.addToRolePolicy(new iam.PolicyStatement({
    actions: ['dynamodb:PutItem'],
    resources: [johnZDynamoDB.tableArn]
  }));
  // both ways add the policy to the role automatically generated via Lambda function creation 

  // trigger the lambda function to insert the data
//  new cdk.CustomResource(this, 'JohnTrigger1Ref', {
//    serviceToken: JohnLambdaFunction.functionArn
//  });
  }
}
